
<?php
// Usamos esta función para encriptar la contraseña de forma segura antes de guardarla en la base de datos
echo password_hash('1234', PASSWORD_DEFAULT);
?>
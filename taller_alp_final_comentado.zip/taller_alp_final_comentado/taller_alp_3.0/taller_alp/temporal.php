<?php
// Con esto sacamos la clave encriptada para que no se guarde en texto plano en la base
// El PASSWORD_DEFAULT ya le pone el mejor algoritmo que tenga PHP por defecto
echo password_hash('1234', PASSWORD_DEFAULT);
?>
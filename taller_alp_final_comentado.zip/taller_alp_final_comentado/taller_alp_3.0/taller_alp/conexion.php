<?php
// Datos básicos para conectarnos a la base de datos local
$host = "127.0.0.1"; 
$user = "root";
$pass = ""; // <--- ESCRIBE AQUÍ TU CONTRASEÑA
$db   = "taller_alp_db";
$port = 3306; // Mantén 3306 o cámbialo a 3307 si ese configuraste en XAMPP

// Aquí hacemos la conexión usando la función de mysqli y pasándole los datos de arriba
$conn = mysqli_connect("127.0.0.1", "root", "", "taller_alp_db", 3306);

// Validamos si la conexión falló por alguna razón
if (!$conn) {
    // Si hay error, paramos todo y mostramos qué pasó para poder solucionar
    die("Error de conexión: " . mysqli_connect_error());
}
?>
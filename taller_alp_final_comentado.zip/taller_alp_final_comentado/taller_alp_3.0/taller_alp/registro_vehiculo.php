<?php
// Iniciamos la sesión para saber quién está navegando [cite: 1]
session_start();
// Si no hay un usuario logueado, lo mandamos directo al login para que no sumbalee por aquí [cite: 1]
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Jalamos el archivo de conexión a la base de datos [cite: 1]
include 'conexion.php';
// Esto lo dejamos activado para que salte cualquier error en la página mientras programamos [cite: 1]
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Guardamos los datos de la sesión en variables más cortas [cite: 1, 2]
$usuario_actual   = $_SESSION['usuario'];
$rol_actual       = $_SESSION['rol']; [cite: 2]
$es_admin         = ($rol_actual === 'admin'); [cite: 2]
// Vemos en qué pestaña/módulo está el usuario, si no hay ninguno por defecto va a 'registro' [cite: 3]
$modulo = isset($_GET['modulo']) ? $_GET['modulo'] : 'registro'; [cite: 3]

/* -----------------------------------------------------
   GUARDAR NUEVO VEHÍCULO
----------------------------------------------------- */
// Si presionaron el botón de guardar vehículo...
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['guardar_vehiculo'])) {
    // Si se cayó la conexión, tiramos alerta [cite: 3]
    if (!$conn) die("<script>alert('Error: No hay conexión a la base de datos.');</script>");
    
    // Limpiamos lo que metió el usuario para evitar caracteres raros o problemas [cite: 4]
    $placa = mysqli_real_escape_string($conn, $_POST['placa']); [cite: 4]
    $marca = mysqli_real_escape_string($conn, $_POST['marca']); [cite: 4]
    $modelo = mysqli_real_escape_string($conn, $_POST['modelo']); [cite: 4]
    $color = mysqli_real_escape_string($conn, $_POST['color']); [cite: 4]
    $id_cliente = mysqli_real_escape_string($conn, $_POST['id_cliente']); [cite: 4]

    // Buscamos si la placa ya existe en la tabla para no duplicar [cite: 5]
    $check_placa = mysqli_query($conn, "SELECT id FROM vehiculos WHERE placa = '$placa'"); [cite: 5]
    if (mysqli_num_rows($check_placa) > 0) { [cite: 6]
        // Si ya hay uno, avisamos y lo devolvemos al registro [cite: 6]
        echo "<script>alert('Error: La placa $placa ya está registrada en el sistema. Verifique e intente de nuevo.'); window.location.href='?modulo=registro';</script>"; [cite: 6]
        exit(); [cite: 7]
    }

    // Si la placa es nueva, metemos los datos en la tabla vehiculos
    $sql = "INSERT INTO vehiculos (placa, marca, modelo, color, id_cliente) 
        VALUES ('$placa', '$marca', '$modelo', '$color', '$id_cliente')";
    if (mysqli_query($conn, $sql)) { [cite: 8]
        // Si todo sale bien, sale alerta de éxito [cite: 8]
        echo "<script>alert('Vehículo registrado con éxito'); window.location.href='?modulo=registro';</script>"; [cite: 8]
    } else { [cite: 9]
        // Si falla la base de datos, mostramos el error que salga [cite: 9]
        $error_bd = mysqli_error($conn); [cite: 9]
        echo "<script>alert('Error: " . addslashes($error_bd) . "');</script>"; [cite: 9]
    }
}

/* -----------------------------------------------------
   GESTIÓN DE USUARIOS (SOLO ADMINISTRADOR)
----------------------------------------------------- */
// Si mandaron el formulario de crear usuario y el que está metido es admin [cite: 10]
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['guardar_usuario']) && $es_admin) {
    // Limpiamos el nombre de usuario y el rol [cite: 10, 11]
    $nuevo_user  = mysqli_real_escape_string($conn, $_POST['nuevo_usuario']); [cite: 10]
    $nuevo_pass  = $_POST['nuevo_password']; // La contraseña la encriptamos abajito [cite: 11]
    $nuevo_rol   = mysqli_real_escape_string($conn, $_POST['nuevo_rol']); [cite: 11]
    // Si no pusieron ID de cliente, le ponemos NULL en la base de datos [cite: 12]
    $nuevo_id_cliente = !empty($_POST['nuevo_id_cliente']) ? intval($_POST['nuevo_id_cliente']) : 'NULL'; [cite: 12]
    // Si no es un cliente, por ley el ID debe ser NULL [cite: 12]
    if ($nuevo_rol !== 'cliente') $nuevo_id_cliente = 'NULL'; [cite: 12]

    // Revisamos que el nombre de usuario no esté repetido [cite: 13]
    $check = mysqli_query($conn, "SELECT id FROM usuarios WHERE username='$nuevo_user'"); [cite: 13]
    if (mysqli_num_rows($check) > 0) { [cite: 14]
        echo "<script>alert('El usuario ya existe');</script>"; [cite: 14]
    } else { [cite: 15]
        // Encriptamos la clave para que no se vea en texto plano en la BD [cite: 15]
        $hash = password_hash($nuevo_pass, PASSWORD_DEFAULT); [cite: 15]
        // Insertamos el nuevo usuario [cite: 16]
        $sql = "INSERT INTO usuarios (username, password, rol, id_cliente) 
                VALUES ('$nuevo_user', '$hash', '$nuevo_rol', $nuevo_id_cliente)"; [cite: 16]
        if (mysqli_query($conn, $sql)) { [cite: 17]
            echo "<script>alert('Usuario creado con éxito'); window.location.href='?modulo=usuarios';</script>"; [cite: 17]
        } else { [cite: 18]
            echo "<script>alert('Error al crear usuario: " . addslashes(mysqli_error($conn)) . "');</script>"; [cite: 18]
        }
    }
}

// Lógica para borrar a alguien (solo si eres admin) [cite: 19]
if (isset($_GET['eliminar_usuario']) && $es_admin) {
    $id_eliminar = (int)$_GET['eliminar_usuario']; [cite: 19]
    // Validamos que no se intente borrar al admin principal (el ID 1) [cite: 20]
    if ($id_eliminar != 1) { [cite: 20]
        mysqli_query($conn, "DELETE FROM usuarios WHERE id = $id_eliminar"); [cite: 20]
    } else { [cite: 21]
        echo "<script>alert('No puedes eliminar al usuario administrador');</script>"; [cite: 21]
    }
    // Refrescamos la pestaña de usuarios [cite: 22]
    echo "<script>window.location.href='?modulo=usuarios';</script>"; [cite: 22]
}

/* -----------------------------------------------------
   REGISTRO DE REPARACIONES (MECÁNICO / ADMIN)
----------------------------------------------------- */
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['guardar_reparacion'])) {
    // Recibimos los datos de la reparación [cite: 22, 23]
    $placa = mysqli_real_escape_string($conn, $_POST['placa_reparacion']); [cite: 22]
    $tipo  = mysqli_real_escape_string($conn, $_POST['tipo_mantenimiento']); [cite: 23]
    $fecha = mysqli_real_escape_string($conn, $_POST['fecha_ingreso']); [cite: 23]

    // Obligatorio: Verificamos si ese carro existe antes de meterle una reparación [cite: 23]
    $check = mysqli_query($conn, "SELECT id FROM vehiculos WHERE placa = '$placa'"); [cite: 23]
    if (mysqli_num_rows($check) == 0) { [cite: 24]
        echo "<script>alert('Vehículo no registrado, por favor registrar.'); window.location.href='?modulo=reparaciones';</script>"; [cite: 24]
        exit(); [cite: 25]
    }

    // Insertamos en la tabla de reparaciones [cite: 25]
    $sql = "INSERT INTO reparaciones (placa, tipo_mantenimiento, fecha_ingreso) 
            VALUES ('$placa', '$tipo', '$fecha')"; [cite: 25]
    if (mysqli_query($conn, $sql)) { [cite: 26]
        echo "<script>alert('Reparación registrada con éxito'); window.location.href='?modulo=reparaciones';</script>"; [cite: 26]
    } else { [cite: 27]
        echo "<script>alert('Error: " . addslashes(mysqli_error($conn)) . "');</script>"; [cite: 27]
    }
}

/* -----------------------------------------------------
   REGISTRO DE TRABAJOS ELÉCTRICOS (ELECTROMECÁNICO / ADMIN)
----------------------------------------------------- */
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['guardar_electricidad'])) {
    // Recibimos los datos del daño eléctrico [cite: 28, 29]
    $placa = mysqli_real_escape_string($conn, $_POST['placa_electricidad']); [cite: 28]
    $desc  = mysqli_real_escape_string($conn, $_POST['descripcion']); [cite: 29]
    $fecha = mysqli_real_escape_string($conn, $_POST['fecha_ingreso_electricidad']); [cite: 29]

    // También chequeamos que el carro exista aquí [cite: 29]
    $check = mysqli_query($conn, "SELECT id FROM vehiculos WHERE placa = '$placa'"); [cite: 29]
    if (mysqli_num_rows($check) == 0) { [cite: 30]
        echo "<script>alert('Vehículo no registrado, por favor registrar.'); window.location.href='?modulo=electricidad';</script>"; [cite: 30]
        exit(); [cite: 31]
    }

    // Guardamos en la tabla de electricidad [cite: 31]
    $sql = "INSERT INTO electricidad (placa, descripcion, fecha_ingreso) 
            VALUES ('$placa', '$desc', '$fecha')"; [cite: 31]
    if (mysqli_query($conn, $sql)) { [cite: 32]
        echo "<script>alert('Trabajo eléctrico registrado con éxito'); window.location.href='?modulo=electricidad';</script>"; [cite: 32]
    } else { [cite: 33]
        echo "<script>alert('Error: " . addslashes(mysqli_error($conn)) . "');</script>"; [cite: 33]
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel - Gestión de Taller</title>
    <style>
        /* Estilos del diseño del sitio */
        body { margin:0; font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif; display:flex; height:100vh; background:#f4f7f6; } [cite: 34, 35]
        .sidebar { width:250px; background:#1e3a5f; color:white; display:flex; flex-direction:column; box-shadow:2px 0 5px rgba(0,0,0,0.1); } [cite: 35, 36]
        .sidebar h2 { text-align:center; padding:25px 0; margin:0; background:#0d1b2a; font-size:22px; letter-spacing:1px; } [cite: 36, 37]
        .sidebar a { color:#c8d6e5; text-decoration:none; padding:15px 20px; border-bottom:1px solid #2a4d7a; transition:0.3s; font-size:15px; } [cite: 37, 38]
        .sidebar a:hover, .sidebar a.activo { background:#007bff; color:white; border-left:5px solid #00a8ff; padding-left:15px; } [cite: 38, 39]
        .sidebar .logout { margin-top:auto; background:#d9534f; text-align:center; border-bottom:none; border-left:none; } [cite: 39, 40]
        .sidebar .logout:hover { background:#c9302c; } [cite: 40, 41]
        .main-content { flex:1; padding:40px; overflow-y:auto; } [cite: 41, 42]
        .card { background:white; padding:30px; border-radius:8px; box-shadow:0 4px 10px rgba(0,0,0,0.05); max-width:500px; margin-bottom:30px; } [cite: 42, 43]
        .card h3, .section-title { margin-top:0; color:#1e3a5f; border-bottom:2px solid #f4f7f6; padding-bottom:10px; } [cite: 43, 44]
        .form-group { margin-bottom:15px; } [cite: 44, 45]
        .form-group label { display:block; margin-bottom:5px; color:#555; font-weight:bold; font-size:14px; } [cite: 45, 46]
        .form-group input, .form-group select { width:100%; padding:12px; border:1px solid #ccc; border-radius:4px; box-sizing:border-box; outline:none; } [cite: 46, 47]
        .form-group input:focus, .form-group select:focus { border-color:#007bff; } [cite: 47, 48]
        .btn-submit { width:100%; background:#007bff; color:white; padding:12px; border:none; border-radius:4px; cursor:pointer; font-size:15px; font-weight:bold; transition:0.3s; margin-top:10px; } [cite: 48, 49]
        .btn-submit:hover { background:#0056b3; } [cite: 49, 50]
        .table-container { background:white; border-radius:8px; box-shadow:0 4px 10px rgba(0,0,0,0.05); overflow:hidden; margin-top:20px; } [cite: 50, 51]
        table { width:100%; border-collapse:collapse; } [cite: 51, 52]
        th, td { padding:15px 20px; text-align:left; border-bottom:1px solid #eee; } [cite: 52, 53]
        th { background-color:#1e3a5f; color:white; font-weight:normal; } [cite: 53, 54]
        tr:hover { background-color:#f9f9f9; } [cite: 54, 55]
        .title-module { color:#1e3a5f; margin-top:0; margin-bottom:20px; } [cite: 55, 56]
        .btn-eliminar { color:#d9534f; text-decoration:none; font-weight:bold; } [cite: 56, 57]
        .btn-eliminar:hover { color:#c9302c; } [cite: 57, 58]
    </style>
</head>
<body>

    <div class="sidebar">
        <h2>Taller ALP</h2>
        <?php
        [cite_start]// Aquí armamos el menú lateral dependiendo del tipo de rol que tenga el usuario [cite: 58]
        $menu = [];
        [cite_start]if ($es_admin) { [cite: 59]
            // El administrador tiene acceso completo a todas las opciones [cite: 59, 60, 61]
            $menu[] = ['?modulo=registro', 'Registro Vehículos']; [cite: 59]
            $menu[] = ['?modulo=lista', 'Lista Vehículos']; [cite: 60]
            $menu[] = ['?modulo=usuarios', 'Usuarios'];
            $menu[] = ['?modulo=reparaciones', 'Reparaciones'];
            $menu[] = ['?modulo=electricidad', 'Sist. Eléctricos'];
            $menu[] = ['?modulo=consulta', 'Consulta']; [cite: 61]
        } elseif ($rol_actual === 'mecanico') { [cite: 61]
            // El mecánico ve registro, reparaciones mecánicas y la lista general [cite: 61, 62, 63]
            $menu[] = ['?modulo=registro', 'Registro Vehículos']; [cite: 61]
            $menu[] = ['?modulo=reparaciones', 'Reparaciones']; [cite: 62]
            $menu[] = ['?modulo=lista', 'Lista Vehículos']; [cite: 63]
        } elseif ($rol_actual === 'electromecanico') { [cite: 63]
            // El de electricidad ve registro, sistema eléctrico y la lista [cite: 63, 64, 65]
            $menu[] = ['?modulo=registro', 'Registro Vehículos']; [cite: 63]
            $menu[] = ['?modulo=electricidad', 'Sist. Eléctricos']; [cite: 64]
            $menu[] = ['?modulo=lista', 'Lista Vehículos']; [cite: 65]
        } elseif ($rol_actual === 'cliente') { [cite: 65]
            // El cliente solo puede chismosear sus propios carros [cite: 65, 66]
            $menu[] = ['?modulo=consulta', 'Mis Vehículos']; [cite: 65]
        }

        // Bucle para pintar los botones del menú en la pantalla [cite: 66]
        foreach ($menu as $item) {
            // Si el enlace coincide con el módulo actual, le ponemos la clase activo para resaltarlo [cite: 66, 67]
            $clase = ($modulo === substr($item[0], 8)) ? 'activo' : ''; [cite: 66, 67]
            echo "<a href='{$item[0]}' class='$clase'>{$item[1]}</a>";
        }
        ?>
        <a href="logout.php" class="logout">Cerrar Sesión</a>
    </div>

    <div class="main-content">

    <div style="background:white; padding:10px 20px; border-radius:8px; margin-bottom:20px; box-shadow:0 2px 5px rgba(0,0,0,0.05);">
    [cite_start]<strong>Bienvenido, <?php echo htmlspecialchars($usuario_actual);[cite: 67, 68]?></strong> 
    (<span style="color:#007bff; text-transform:capitalize;"><?php echo htmlspecialchars($rol_actual); ?></span>)
        </div>

        <?php if ($modulo == 'registro' && in_array($rol_actual, ['admin','mecanico','electromecanico'])): ?>
            <div class="card">
                <h3>Nuevo Vehículo</h3>
                <form method="POST" action="?modulo=registro">
                  
                    [cite_start]<input type="hidden" name="guardar_vehiculo" value="1"> [cite: 69]
                    <div class="form-group"><label>Placa</label><input type="text" name="placa" required></div>
                    <div class="form-group"><label>Marca</label><input type="text" name="marca" required></div>
                    <div class="form-group"><label>Modelo</label><input type="text" name="modelo" required></div>
                    [cite_start]<div class="form-group"><label>Color</label><input type="text" name="color" required></div> [cite: 69, 70]
                    <div class="form-group"><label>ID Cliente</label><input type="number" name="id_cliente" required></div>
                    <button type="submit" class="btn-submit">Guardar</button>
                </form>
            </div>

        <?php elseif ($modulo == 'lista' && in_array($rol_actual, ['admin','mecanico','electromecanico'])): ?>
        
            [cite_start]<h2 class="title-module">Vehículos Registrados</h2> [cite: 71]
            <div class="table-container"><table>
                <tr><th>ID</th><th>Placa</th><th>Marca</th><th>Modelo</th><th>Color</th><th>ID Cliente</th></tr>
                <?php
                [cite_start]// Consultamos todos los vehículos ordenados por el último que se ingresó [cite: 71]
                [cite_start]$res = mysqli_query($conn, "SELECT * FROM vehiculos ORDER BY id DESC"); [cite: 71]
                [cite_start]while ($f = mysqli_fetch_assoc($res)) { [cite: 72]
                    // Recorremos las filas y las imprimimos en celdas [cite: 72]
                    echo "<tr>
                        <td>{$f['id']}</td><td><strong>{$f['placa']}</strong></td>
                        <td>{$f['marca']}</td><td>{$f['modelo']}</td>
                        <td>{$f['color']}</td><td>{$f['id_cliente']}</td>
                     </tr>"; [cite: 72, 73]
                } [cite: 74]
                ?>
            </table></div>

        <?php elseif ($modulo == 'usuarios' && $es_admin): ?>
            <div class="card">
                <h3>Crear Usuario</h3>
                <form method="POST" action="?modulo=usuarios">
         
                    [cite_start]<input type="hidden" name="guardar_usuario" value="1"> [cite: 75]
                    <div class="form-group"><label>Usuario</label><input type="text" name="nuevo_usuario" required></div>
                    <div class="form-group"><label>Contraseña</label><input type="password" name="nuevo_password" required></div>
                    <div class="form-group">
                 
                        <label>Rol</label>
                        [cite_start]<select name="nuevo_rol" id="nuevo_rol" onchange="toggleIdCliente()"> [cite: 76]
                            <option value="cliente">Cliente</option>
                            <option value="mecanico">Mecánico</option>
                             [cite_start]<option value="electromecanico">Electromecánico</option> [cite: 77]
                            <option value="admin">Admin</option>
                        </select>
                    </div>
      
                    [cite_start]<div class="form-group" id="grupo_id_cliente"> [cite: 78]
                        <label>ID Cliente (solo para clientes)</label>
                        <input type="number" name="nuevo_id_cliente">
                    </div>
          
                   [cite_start]<button type="submit" class="btn-submit">Crear</button> [cite: 79]
                </form>
                <script>
                [cite_start]// Función JS sencilla para ocultar/mostrar la casilla del ID de cliente [cite: 79]
                function toggleIdCliente() {
                    var rol = document.getElementById('nuevo_rol').value; [cite: 79, 80]
                    document.getElementById('grupo_id_cliente').style.display = (rol === 'cliente') ? 'block' : 'none'; [cite: 80]
                }
                toggleIdCliente(); // Se ejecuta al cargar la página para dejarlo listo [cite: 80, 81]
                </script>
            </div>
            
            <h2 class="title-module">Usuarios existentes</h2>
            <div class="table-container"><table>
                <tr><th>ID</th><th>Usuario</th><th>Rol</th><th>ID Cliente</th><th>Acción</th></tr>
                <?php
                  [cite_start]// Traemos los usuarios de la base de datos [cite: 81, 82]
                  [cite_start]$ures = mysqli_query($conn, "SELECT id, username, rol, id_cliente FROM usuarios"); [cite: 82]
                [cite_start]while ($u = mysqli_fetch_assoc($ures)) { [cite: 83]
                    // Si es el ID 1 no dejamos borrarlo (es el admin principal) [cite: 83]
                    $accion = ($u['id'] != 1) [cite: 83]
                        ? "<a href='?modulo=usuarios&eliminar_usuario={$u['id']}' class='btn-eliminar' onclick=\"return confirm('¿Eliminar?')\">Eliminar</a>" [cite: 84]
                        : "<span style='color:#aaa;'>Admin</span>"; [cite: 84]
                    echo "<tr>
                        <td>{$u['id']}</td><td><strong>{$u['username']}</strong></td>
                        <td>{$u['rol']}</td><td>{$u['id_cliente']}</td>
                        <td>{$accion}</td>
                    </tr>"; [cite: 85]
                } [cite: 86]
                ?>
            </table></div>

        <?php elseif ($modulo == 'reparaciones' && in_array($rol_actual, ['admin','mecanico'])): ?>
            <div class="card">
                <h3>Nueva Reparación</h3>
                <form method="POST" action="?modulo=reparaciones">
        
                    [cite_start]<input type="hidden" name="guardar_reparacion" value="1"> [cite: 87]
                    <div class="form-group"><label>Placa</label><input type="text" name="placa_reparacion" required></div>
                    <div class="form-group">
                        <label>Tipo</label>
                        [cite_start]<select name="tipo_mantenimiento" required> [cite: 88]
                            <option value="">Seleccione...</option>
                            <option value="Preventivo">Preventivo</option>
                            <option value="Correctivo">Correctivo</option>
                       [cite_start]</select> [cite: 88, 89]
                    </div>
                    [cite_start]<div class="form-group"><label>Fecha</label><input type="date" name="fecha_ingreso" value="<?= date('Y-m-d') ?>" required></div> [cite: 89]
                    <button type="submit" class="btn-submit">Guardar</button>
               [cite_start]</form> [cite: 90]
            </div>
            
            <h2 class="title-module">Historial de Reparaciones</h2>
            <div class="table-container"><table>
                <tr><th>ID</th><th>Placa</th><th>Tipo</th><th>Fecha</th></tr>
                <?php
                [cite_start]$rrep = mysqli_query($conn, "SELECT * FROM reparaciones ORDER BY id DESC"); [cite: 90, 91]
                [cite_start]while ($r = mysqli_fetch_assoc($rrep)) { [cite: 91]
                    // Imprimimos dándoles formato de día/mes/año a la fecha [cite: 91, 92]
                    echo "<tr>
                        <td>{$r['id']}</td><td><strong>{$r['placa']}</strong></td>
                        <td>{$r['tipo_mantenimiento']}</td><td>" . date("d/m/Y", strtotime($r['fecha_ingreso'])) . "</td>
                    </tr>"; [cite: 91, 92]
                } [cite: 93]
                ?>
            </table></div>

        <?php elseif ($modulo == 'electricidad' && in_array($rol_actual, ['admin','electromecanico'])): ?>
            <div class="card">
                <h3>Nuevo Trabajo Eléctrico</h3>
                <form method="POST" action="?modulo=electricidad">
       
                    [cite_start]<input type="hidden" name="guardar_electricidad" value="1"> [cite: 94]
                    <div class="form-group"><label>Placa</label><input type="text" name="placa_electricidad" required></div>
                    [cite_start]<div class="form-group"><label>Descripción del sistema</label><input type="text" name="descripcion" placeholder="Ej: Cambio de alternador" required></div> [cite: 94]
                    [cite_start]<div class="form-group"><label>Fecha</label><input type="date" name="fecha_ingreso_electricidad" value="<?= date('Y-m-d') ?>" required></div> [cite: 94]
                     [cite_start]<button type="submit" class="btn-submit">Guardar</button> [cite: 95]
                </form>
            </div>
            
            <h2 class="title-module">Historial Eléctrico</h2>
            <div class="table-container"><table>
                <tr><th>ID</th><th>Placa</th><th>Descripción</th><th>Fecha</th></tr>
                 [cite_start]<?php [cite: 95, 96]
                [cite_start]$elec = mysqli_query($conn, "SELECT * FROM electricidad ORDER BY id DESC"); [cite: 96]
                [cite_start]while ($e = mysqli_fetch_assoc($elec)) { [cite: 97]
                    echo "<tr>
                        <td>{$e['id']}</td><td><strong>{$e['placa']}</strong></td>
                        <td>{$e['descripcion']}</td><td>" . date("d/m/Y", strtotime($e['fecha_ingreso'])) . "</td>
                    </tr>"; [cite: 97, 98]
                } [cite: 99]
                ?>
            </table></div>
            

        <?php elseif ($modulo == 'consulta' && in_array($rol_actual, ['admin','cliente'])): 
    // Sección de consultas globales o específicas de clientes [cite: 99]
    if ($rol_actual === 'cliente') { [cite: 100]
        // Si es cliente, primero buscamos su ID interno para amarrar la consulta [cite: 100]
        $user_info = mysqli_query($conn, "SELECT id_cliente FROM usuarios WHERE username='$usuario_actual'"); [cite: 100]
        $cliente_id = ($c = mysqli_fetch_assoc($user_info)) ? $c['id_cliente'] : 0; [cite: 101]
        // Filtramos para que no vea carros ajenos [cite: 101]
        $filtro = "WHERE v.id_cliente = $cliente_id"; [cite: 101]
    } else { [cite: 101, 102]
        // Si es admin, dejamos la variable vacía para traer absolutamente todo [cite: 102, 103]
        $filtro = ""; [cite: 102]
    }
?>
    <h2 class="title-module">Consulta de Vehículos y Servicios</h2>
    <?php
    [cite_start]// Query avanzado que junta datos del vehículo y concatena sus reparaciones y trabajos eléctricos en una sola cadena usando subconsultas [cite: 103, 104, 105, 106]
    $sql_vehiculos = "SELECT v.placa, v.marca, v.modelo, v.color, v.anio, v.id_cliente, " .
        [cite_start]"(SELECT GROUP_CONCAT(CONCAT('Rep: ', tipo_mantenimiento, ' (', fecha_ingreso, ') ') SEPARATOR '<br>') " . [cite: 104]
        "FROM reparaciones WHERE placa = v.placa) AS reparaciones, " .
        [cite_start]"(SELECT GROUP_CONCAT(CONCAT('Elec: ', descripcion, ' (', fecha_ingreso, ') ') SEPARATOR '<br>') " . [cite: 105]
        "FROM electricidad WHERE placa = v.placa) AS electricidad " .
        [cite_start]"FROM vehiculos v $filtro ORDER BY v.placa"; [cite: 106]
    
    [cite_start]$res_consulta = mysqli_query($conn, $sql_vehiculos); [cite: 106]
    [cite_start]if ($res_consulta && mysqli_num_rows($res_consulta) > 0) { [cite: 107]
        // Pintamos los datos del carro en tarjetas individuales [cite: 107]
        while ($v = mysqli_fetch_assoc($res_consulta)) { [cite: 107]
            echo "<div class='card' style='max-width:700px'>
                <h4>{$v['marca']} {$v['modelo']} - <strong>{$v['placa']}</strong></h4>
                <p><strong>Año:</strong> {$v['anio']} &nbsp;|&nbsp; <strong>Color:</strong> {$v['color']} &nbsp;|&nbsp; <strong>ID Cliente:</strong> {$v['id_cliente']}</p>
                <div style='background:#f1f1f1;padding:10px;border-radius:4px;'>
                     <strong>Reparaciones:</strong><br>" [cite: 107, 108]
                    . ($v['reparaciones'] ?? 'Sin reparaciones') . // Si es null, mostramos texto por defecto [cite: 109]
                    "<br><br><strong>Sistemas Eléctricos:</strong><br>"
                    . ($v['electricidad'] ?? 'Sin trabajos eléctricos') . [cite: 110]
                "</div>
              </div><br>";
        } [cite: 111]
    } else { [cite: 111, 112]
        echo "<p>No hay vehículos para mostrar.</p>"; [cite: 112]
    }
    endif; 
?>

    </div>

</body>
</html>
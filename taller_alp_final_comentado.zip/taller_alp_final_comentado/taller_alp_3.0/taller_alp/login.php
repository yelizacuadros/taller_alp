<?php
// Esto es para que PHP me muestre si hay algún error en la pantalla mientras programamos

ini_set('display_errors', 1);
error_reporting(E_ALL);

// Iniciamos la sesión para poder guardar los datos del usuario que se loguea
session_start();

// Traemos el archivo de la conexión para poder usar la base de datos
include 'conexion.php';

// Validamos si el usuario le dio al botón de enviar el formulario (método POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Agarramos lo que el usuario escribió en las cajas de texto
    $user = $_POST['usuario'];
    $pass = $_POST['contrasena'];

    // Preparamos la consulta para buscar al usuario de forma segura y evitar problemas
    $stmt = mysqli_prepare($conn, "SELECT password, rol FROM usuarios WHERE username = ?");
    mysqli_stmt_bind_param($stmt, "s", $user);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    // Si encuentra al usuario en la base de datos, entra aquí
    if ($fila = mysqli_fetch_assoc($result)) {
       // Validamos si las credenciales coinciden con las del administrador (root)
       if ($user == "root" && $pass == "12345") {
            // Guardamos el nombre y el rol en la sesión para usarlos en las otras páginas
            $_SESSION['usuario'] = $user;
            $_SESSION['rol'] = $fila['rol'];    
            
            // Si todo está bien, lo mandamos directo a la página de registro de vehículos
            header("Location: registro_vehiculo.php");
            exit();
        }
    }
    // Si el usuario no existe o la clave está mal, mandamos una alerta en la pantalla
    echo "<script>alert('Usuario o contraseña incorrectos');</script>";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceso al sistema - Taller ALP</title>
    <!-- Iconos para que el formulario se vea mejor -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
    /* Estilos para el fondo de toda la página */
    body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    /* Un fondo oscuro con degradado circular */
    background: radial-gradient(circle at center, #1e3a5f 0%, #0d1b2a 100%);
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
}

/* Diseño del cuadro blanco del login */
.login-box {
    width: 320px;
    padding: 40px 30px;
    background: #ffffff; 
    border: 1px solid #cccccc; 
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2); 
    border-radius: 20px;
    box-sizing: border-box;
    text-align: center;
}

/* Estilo del título principal */
h2 {
    color: #000000; 
    font-weight: bold;
    margin-bottom: 25px;
    font-size: 22px;
}

/* El círculo donde va el icono de usuario */
.avatar {
    width: 70px;
    height: 70px;
    margin: 0 auto 30px auto;
    border: 2px solid #555555; 
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 30px;
    color: #555555;
}

/* Contenedor para alinear los inputs y sus iconos internos */
.input-group {
    position: relative;
    margin-bottom: 20px;
    width: 100%;
}

/* Posición de los iconos dentro de las cajas de texto */
.input-group i {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: #888888; 
    font-size: 14px;
}

/* Estilo general de las cajas de texto (usuario y clave) */
.input-group input {
    width: 100%;
    padding: 12px 10px 12px 40px;
    background: #f8f9fa; 
    border: 1px solid #dddddd;
    border-radius: 4px;
    color: #333333;
    font-size: 14px;
    box-sizing: border-box;
    outline: none;
    transition: 0.3s;
}

/* Cambio de color cuando el usuario hace clic en la caja de texto */
.input-group input:focus {
    border-color: #999999;
}

/* Color del texto de sugerencia de fondo (placeholder) */
.input-group input::placeholder {
    color: #aaaaaa;
}

/* Diseño del botón de entrar con un degradado azul */
.btn-login {
    width: 100%;
    padding: 12px;
    background: linear-gradient(to bottom, #5ab0ee 0%, #2980b9 100%);
    border: 1px solid #1a649a;
    border-radius: 6px;
    color: #ffffff; 
    font-size: 14px;
    font-weight: bold;
    letter-spacing: 1px;
    cursor: pointer;
    text-transform: uppercase;
    transition: 0.3s;
    margin-top: 10px;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.4), 0 2px 4px rgba(0,0,0,0.2);
}

/* Efecto visual cuando pasamos el mouse por encima del botón */
.btn-login:hover {
    background: linear-gradient(to bottom, #4a9fdd 0%, #1e70a6 100%);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.4), 0 4px 8px rgba(0,0,0,0.3);
}
    </style>
</head>
<body>
    <div class="login-box">
        <div class="avatar"><i class="fa-solid fa-user"></i></div>
        <form method="POST">
            <h2>Acceso al sistema</h2>
            <div class="input-group">
                <i class="fa-solid fa-id-badge"></i>
                <input type="text" name="usuario" class="input-form" placeholder="ID" required>
            <<div>
     <input type="password" name="contrasena" id="contrasena">
     <!-- BOTÓN CORREGIDO -->
     <button type="button" id="verPass">👁️ Ver</button>
 </div>
 <!-- SCRIPT FUERA DEL DIV, AL FINAL O ANTES DE </body> -->
 <script>
 // Esperamos que cargue toda la estructura de la página antes de ejecutar el JS
 document.addEventListener("DOMContentLoaded", function() {
     // Obtenemos los elementos de la contraseña y el botón por su ID
     const campo = document.getElementById("contrasena");
     const boton = document.getElementById("verPass");
     
     // Evento para cuando el usuario hace clic en el botón de ver/ocultar
     boton.addEventListener("click", function() {
         // Si está oculto (tipo password), lo cambiamos a tipo texto para que se pueda leer
         if (campo.type === "password") {
             campo.type = "text";
             boton.textContent = "🙈 Ocultar";
         } else {
             // Si ya se estaba viendo, lo volvemos a poner como password para ocultarlo
             campo.type = "password";
             boton.textContent = "👁️ Ver";
         }
     });
 });
 </script>

</script>
            </div>
            <button type="submit" class="btn-login">ENTRAR</button>
        </form>
    </div>
</body>
</html>
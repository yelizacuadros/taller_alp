<?php
// Primero abrimos la sesión actual para saber a quién vamos a desconectar
session_start();

// Borramos absolutamente todos los datos que estaban guardados en la sesión
session_destroy();

// Mandamos al usuario de regreso a la página del login automáticamente
header("Location: login.php");

// Ponemos el exit para asegurarnos de que el código se detenga por completo aquí
exit();
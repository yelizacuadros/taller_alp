<?php
$host = "127.0.0.1"; 
$user = "root";
$pass = ""; // <--- ESCRIBE AQUÍ TU CONTRASEÑA
$db   = "taller_alp_db";
$port = 3306; // Mantén 3306 o cámbialo a 3307 si ese configuraste en XAMPP

$conn = mysqli_connect("127.0.0.1", "root", "", "taller_alp_db", 3306);

if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}
?>
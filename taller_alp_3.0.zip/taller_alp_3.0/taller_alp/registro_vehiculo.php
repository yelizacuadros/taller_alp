<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

include 'conexion.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$usuario_actual   = $_SESSION['usuario'];
$rol_actual       = $_SESSION['rol'];
$es_admin         = ($rol_actual === 'admin');

$modulo = isset($_GET['modulo']) ? $_GET['modulo'] : 'registro';

/* -----------------------------------------------------
   LÓGICA PARA GUARDAR VEHÍCULO (todos pueden registrar,
   pero conviene limitarlo según el rol si lo deseas)
----------------------------------------------------- */
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['guardar_vehiculo'])) {
    if (!$conn) die("<script>alert('Error: No hay conexión a la base de datos.');</script>");
    $placa = mysqli_real_escape_string($conn, $_POST['placa']);
    $marca = mysqli_real_escape_string($conn, $_POST['marca']);
    $modelo = mysqli_real_escape_string($conn, $_POST['modelo']);
    $color = mysqli_real_escape_string($conn, $_POST['color']);
    $id_cliente = mysqli_real_escape_string($conn, $_POST['id_cliente']);

    // --- VERIFICAR SI LA PLACA YA EXISTE ---
    $check_placa = mysqli_query($conn, "SELECT id FROM vehiculos WHERE placa = '$placa'");
    if (mysqli_num_rows($check_placa) > 0) {
        echo "<script>alert('Error: La placa $placa ya está registrada en el sistema. Verifique e intente de nuevo.'); window.location.href='?modulo=registro';</script>";
        exit();
    }

    // Si no existe, se procede a insertar
    $sql = "INSERT INTO vehiculos (placa, marca, modelo, color, id_cliente) 
        VALUES ('$placa', '$marca', '$modelo', '$color', '$id_cliente')";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Vehículo registrado con éxito'); window.location.href='?modulo=registro';</script>";
    } else {
        $error_bd = mysqli_error($conn);
        echo "<script>alert('Error: " . addslashes($error_bd) . "');</script>";
    }
}

/* -----------------------------------------------------
   LÓGICA PARA USUARIOS (solo admin)
----------------------------------------------------- */
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['guardar_usuario']) && $es_admin) {
    $nuevo_user  = mysqli_real_escape_string($conn, $_POST['nuevo_usuario']);
    $nuevo_pass  = $_POST['nuevo_password']; // lo hasheamos después
    $nuevo_rol   = mysqli_real_escape_string($conn, $_POST['nuevo_rol']);
    $nuevo_id_cliente = !empty($_POST['nuevo_id_cliente']) ? intval($_POST['nuevo_id_cliente']) : 'NULL';
    if ($nuevo_rol !== 'cliente') $nuevo_id_cliente = 'NULL'; // solo clientes llevan id

    $check = mysqli_query($conn, "SELECT id FROM usuarios WHERE username='$nuevo_user'");
    if (mysqli_num_rows($check) > 0) {
        echo "<script>alert('El usuario ya existe');</script>";
    } else {
        $hash = password_hash($nuevo_pass, PASSWORD_DEFAULT);
        $sql = "INSERT INTO usuarios (username, password, rol, id_cliente) 
                VALUES ('$nuevo_user', '$hash', '$nuevo_rol', $nuevo_id_cliente)";
        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('Usuario creado con éxito'); window.location.href='?modulo=usuarios';</script>";
        } else {
            echo "<script>alert('Error al crear usuario: " . addslashes(mysqli_error($conn)) . "');</script>";
        }
    }
}

if (isset($_GET['eliminar_usuario']) && $es_admin) {
    $id_eliminar = (int)$_GET['eliminar_usuario'];
    if ($id_eliminar != 1) { // no borrar admin
        mysqli_query($conn, "DELETE FROM usuarios WHERE id = $id_eliminar");
    } else {
        echo "<script>alert('No puedes eliminar al usuario administrador');</script>";
    }
    echo "<script>window.location.href='?modulo=usuarios';</script>";
}

/* -----------------------------------------------------
   LÓGICA PARA REPARACIONES (mecánico / admin)
----------------------------------------------------- */
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['guardar_reparacion'])) {
    $placa = mysqli_real_escape_string($conn, $_POST['placa_reparacion']);
    $tipo  = mysqli_real_escape_string($conn, $_POST['tipo_mantenimiento']);
    $fecha = mysqli_real_escape_string($conn, $_POST['fecha_ingreso']);

    // Verificar que el vehículo existe
    $check = mysqli_query($conn, "SELECT id FROM vehiculos WHERE placa = '$placa'");
    if (mysqli_num_rows($check) == 0) {
        echo "<script>alert('Vehículo no registrado, por favor registrar.'); window.location.href='?modulo=reparaciones';</script>";
        exit();
    }

    $sql = "INSERT INTO reparaciones (placa, tipo_mantenimiento, fecha_ingreso) 
            VALUES ('$placa', '$tipo', '$fecha')";
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Reparación registrada con éxito'); window.location.href='?modulo=reparaciones';</script>";
    } else {
        echo "<script>alert('Error: " . addslashes(mysqli_error($conn)) . "');</script>";
    }
}

/* -----------------------------------------------------
   LÓGICA PARA SISTEMAS ELÉCTRICOS (electromecánico / admin)
----------------------------------------------------- */
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['guardar_electricidad'])) {
    $placa = mysqli_real_escape_string($conn, $_POST['placa_electricidad']);
    $desc  = mysqli_real_escape_string($conn, $_POST['descripcion']);
    $fecha = mysqli_real_escape_string($conn, $_POST['fecha_ingreso_electricidad']);

    $check = mysqli_query($conn, "SELECT id FROM vehiculos WHERE placa = '$placa'");
    if (mysqli_num_rows($check) == 0) {
        echo "<script>alert('Vehículo no registrado, por favor registrar.'); window.location.href='?modulo=electricidad';</script>";
        exit();
    }

    $sql = "INSERT INTO electricidad (placa, descripcion, fecha_ingreso) 
            VALUES ('$placa', '$desc', '$fecha')";
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Trabajo eléctrico registrado con éxito'); window.location.href='?modulo=electricidad';</script>";
    } else {
        echo "<script>alert('Error: " . addslashes(mysqli_error($conn)) . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel - Gestión de Taller</title>
    <style>
        /* Estilos generales (idénticos al anterior) */
        body { margin:0; font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif; display:flex; height:100vh; background:#f4f7f6; }
        .sidebar { width:250px; background:#1e3a5f; color:white; display:flex; flex-direction:column; box-shadow:2px 0 5px rgba(0,0,0,0.1); }
        .sidebar h2 { text-align:center; padding:25px 0; margin:0; background:#0d1b2a; font-size:22px; letter-spacing:1px; }
        .sidebar a { color:#c8d6e5; text-decoration:none; padding:15px 20px; border-bottom:1px solid #2a4d7a; transition:0.3s; font-size:15px; }
        .sidebar a:hover, .sidebar a.activo { background:#007bff; color:white; border-left:5px solid #00a8ff; padding-left:15px; }
        .sidebar .logout { margin-top:auto; background:#d9534f; text-align:center; border-bottom:none; border-left:none; }
        .sidebar .logout:hover { background:#c9302c; }
        .main-content { flex:1; padding:40px; overflow-y:auto; }
        .card { background:white; padding:30px; border-radius:8px; box-shadow:0 4px 10px rgba(0,0,0,0.05); max-width:500px; margin-bottom:30px; }
        .card h3, .section-title { margin-top:0; color:#1e3a5f; border-bottom:2px solid #f4f7f6; padding-bottom:10px; }
        .form-group { margin-bottom:15px; }
        .form-group label { display:block; margin-bottom:5px; color:#555; font-weight:bold; font-size:14px; }
        .form-group input, .form-group select { width:100%; padding:12px; border:1px solid #ccc; border-radius:4px; box-sizing:border-box; outline:none; }
        .form-group input:focus, .form-group select:focus { border-color:#007bff; }
        .btn-submit { width:100%; background:#007bff; color:white; padding:12px; border:none; border-radius:4px; cursor:pointer; font-size:15px; font-weight:bold; transition:0.3s; margin-top:10px; }
        .btn-submit:hover { background:#0056b3; }
        .table-container { background:white; border-radius:8px; box-shadow:0 4px 10px rgba(0,0,0,0.05); overflow:hidden; margin-top:20px; }
        table { width:100%; border-collapse:collapse; }
        th, td { padding:15px 20px; text-align:left; border-bottom:1px solid #eee; }
        th { background-color:#1e3a5f; color:white; font-weight:normal; }
        tr:hover { background-color:#f9f9f9; }
        .title-module { color:#1e3a5f; margin-top:0; margin-bottom:20px; }
        .btn-eliminar { color:#d9534f; text-decoration:none; font-weight:bold; }
        .btn-eliminar:hover { color:#c9302c; }
    </style>
</head>
<body>

    <div class="sidebar">
        <h2>Taller ALP</h2>
        <?php
        // Menú según rol
        $menu = [];

        if ($es_admin) {
             $menu[] = ['?modulo=registro', 'Registro Vehículos'];
            $menu[] = ['?modulo=lista', 'Lista Vehículos'];
            $menu[] = ['?modulo=usuarios', 'Usuarios'];
             $menu[] = ['?modulo=reparaciones', 'Reparaciones'];
            $menu[] = ['?modulo=electricidad', 'Sist. Eléctricos'];
            $menu[] = ['?modulo=consulta', 'Consulta'];
        } elseif ($rol_actual === 'mecanico') {
            $menu[] = ['?modulo=registro', 'Registro Vehículos'];   // ← añadido
            $menu[] = ['?modulo=reparaciones', 'Reparaciones'];
            $menu[] = ['?modulo=lista', 'Lista Vehículos'];
        } elseif ($rol_actual === 'electromecanico') {
            $menu[] = ['?modulo=registro', 'Registro Vehículos'];   // ← añadido
            $menu[] = ['?modulo=electricidad', 'Sist. Eléctricos'];
            $menu[] = ['?modulo=lista', 'Lista Vehículos'];
        } elseif ($rol_actual === 'cliente') {
            $menu[] = ['?modulo=consulta', 'Mis Vehículos'];
}

        foreach ($menu as $item) {
            $clase = ($modulo === substr($item[0], 8)) ? 'activo' : '';
            echo "<a href='{$item[0]}' class='$clase'>{$item[1]}</a>";
        }
        ?>
        <a href="logout.php" class="logout">Cerrar Sesión</a>
    </div>

    <div class="main-content">

    <div style="background:white; padding:10px 20px; border-radius:8px; margin-bottom:20px; box-shadow:0 2px 5px rgba(0,0,0,0.05);">
    <strong>Bienvenido, <?php echo htmlspecialchars($usuario_actual); ?></strong> 
    (<span style="color:#007bff; text-transform:capitalize;"><?php echo htmlspecialchars($rol_actual); ?></span>)
        </div>

        <?php if ($modulo == 'registro' && in_array($rol_actual, ['admin','mecanico','electromecanico'])): ?>
            <div class="card">
                <h3>Nuevo Vehículo</h3>
                <form method="POST" action="?modulo=registro">
                    <input type="hidden" name="guardar_vehiculo" value="1">
                    <div class="form-group"><label>Placa</label><input type="text" name="placa" required></div>
                    <div class="form-group"><label>Marca</label><input type="text" name="marca" required></div>
                    <div class="form-group"><label>Modelo</label><input type="text" name="modelo" required></div>
                    <div class="form-group"><label>Color</label><input type="text" name="color" required></div>
                    <div class="form-group"><label>ID Cliente</label><input type="number" name="id_cliente" required></div>
                    <button type="submit" class="btn-submit">Guardar</button>
                </form>
            </div>

        <?php elseif ($modulo == 'lista' && in_array($rol_actual, ['admin','mecanico','electromecanico'])): ?>
            <h2 class="title-module">Vehículos Registrados</h2>
            <div class="table-container"><table>
                <tr><th>ID</th><th>Placa</th><th>Marca</th><th>Modelo</th><th>Color</th><th>ID Cliente</th></tr>
                <?php
                $res = mysqli_query($conn, "SELECT * FROM vehiculos ORDER BY id DESC");
                while ($f = mysqli_fetch_assoc($res)) {
                    echo "<tr>
                        <td>{$f['id']}</td><td><strong>{$f['placa']}</strong></td>
                        <td>{$f['marca']}</td><td>{$f['modelo']}</td>
                        <td>{$f['color']}</td><td>{$f['id_cliente']}</td>
                    </tr>";
                }
                ?>
            </table></div>

        <?php elseif ($modulo == 'usuarios' && $es_admin): ?>
            <div class="card">
                <h3>Crear Usuario</h3>
                <form method="POST" action="?modulo=usuarios">
                    <input type="hidden" name="guardar_usuario" value="1">
                    <div class="form-group"><label>Usuario</label><input type="text" name="nuevo_usuario" required></div>
                    <div class="form-group"><label>Contraseña</label><input type="password" name="nuevo_password" required></div>
                    <div class="form-group">
                        <label>Rol</label>
                        <select name="nuevo_rol" id="nuevo_rol" onchange="toggleIdCliente()">
                            <option value="cliente">Cliente</option>
                            <option value="mecanico">Mecánico</option>
                            <option value="electromecanico">Electromecánico</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <div class="form-group" id="grupo_id_cliente">
                        <label>ID Cliente (solo para clientes)</label>
                        <input type="number" name="nuevo_id_cliente">
                    </div>
                    <button type="submit" class="btn-submit">Crear</button>
                </form>
                <script>
                function toggleIdCliente() {
                    var rol = document.getElementById('nuevo_rol').value;
                    document.getElementById('grupo_id_cliente').style.display = (rol === 'cliente') ? 'block' : 'none';
                }
                toggleIdCliente(); // inicial
                </script>
            </div>
            <h2 class="title-module">Usuarios existentes</h2>
            <div class="table-container"><table>
                <tr><th>ID</th><th>Usuario</th><th>Rol</th><th>ID Cliente</th><th>Acción</th></tr>
                <?php
                $ures = mysqli_query($conn, "SELECT id, username, rol, id_cliente FROM usuarios");
                while ($u = mysqli_fetch_assoc($ures)) {
                    $accion = ($u['id'] != 1)
                        ? "<a href='?modulo=usuarios&eliminar_usuario={$u['id']}' class='btn-eliminar' onclick=\"return confirm('¿Eliminar?')\">Eliminar</a>"
                        : "<span style='color:#aaa;'>Admin</span>";
                    echo "<tr>
                        <td>{$u['id']}</td><td><strong>{$u['username']}</strong></td>
                        <td>{$u['rol']}</td><td>{$u['id_cliente']}</td>
                        <td>{$accion}</td>
                    </tr>";
                }
                ?>
            </table></div>

        <?php elseif ($modulo == 'reparaciones' && in_array($rol_actual, ['admin','mecanico'])): ?>
            <div class="card">
                <h3>Nueva Reparación</h3>
                <form method="POST" action="?modulo=reparaciones">
                    <input type="hidden" name="guardar_reparacion" value="1">
                    <div class="form-group"><label>Placa</label><input type="text" name="placa_reparacion" required></div>
                    <div class="form-group">
                        <label>Tipo</label>
                        <select name="tipo_mantenimiento" required>
                            <option value="">Seleccione...</option>
                            <option value="Preventivo">Preventivo</option>
                            <option value="Correctivo">Correctivo</option>
                        </select>
                    </div>
                    <div class="form-group"><label>Fecha</label><input type="date" name="fecha_ingreso" value="<?= date('Y-m-d') ?>" required></div>
                    <button type="submit" class="btn-submit">Guardar</button>
                </form>
            </div>
            <h2 class="title-module">Historial de Reparaciones</h2>
            <div class="table-container"><table>
                <tr><th>ID</th><th>Placa</th><th>Tipo</th><th>Fecha</th></tr>
                <?php
                $rrep = mysqli_query($conn, "SELECT * FROM reparaciones ORDER BY id DESC");
                while ($r = mysqli_fetch_assoc($rrep)) {
                    echo "<tr>
                        <td>{$r['id']}</td><td><strong>{$r['placa']}</strong></td>
                        <td>{$r['tipo_mantenimiento']}</td><td>" . date("d/m/Y", strtotime($r['fecha_ingreso'])) . "</td>
                    </tr>";
                }
                ?>
            </table></div>

        <?php elseif ($modulo == 'electricidad' && in_array($rol_actual, ['admin','electromecanico'])): ?>
            <div class="card">
                <h3>Nuevo Trabajo Eléctrico</h3>
                <form method="POST" action="?modulo=electricidad">
                    <input type="hidden" name="guardar_electricidad" value="1">
                    <div class="form-group"><label>Placa</label><input type="text" name="placa_electricidad" required></div>
                    <div class="form-group"><label>Descripción del sistema</label><input type="text" name="descripcion" placeholder="Ej: Cambio de alternador" required></div>
                    <div class="form-group"><label>Fecha</label><input type="date" name="fecha_ingreso_electricidad" value="<?= date('Y-m-d') ?>" required></div>
                    <button type="submit" class="btn-submit">Guardar</button>
                </form>
            </div>
            <h2 class="title-module">Historial Eléctrico</h2>
            <div class="table-container"><table>
                <tr><th>ID</th><th>Placa</th><th>Descripción</th><th>Fecha</th></tr>
                <?php
                $elec = mysqli_query($conn, "SELECT * FROM electricidad ORDER BY id DESC");
                while ($e = mysqli_fetch_assoc($elec)) {
                    echo "<tr>
                        <td>{$e['id']}</td><td><strong>{$e['placa']}</strong></td>
                        <td>{$e['descripcion']}</td><td>" . date("d/m/Y", strtotime($e['fecha_ingreso'])) . "</td>
                    </tr>";
                }
                ?>
            </table></div>
            

        <?php elseif ($modulo == 'consulta' && in_array($rol_actual, ['admin','cliente'])): 
    // Para clientes se filtra por su id_cliente; admin ve la consulta libre
    if ($rol_actual === 'cliente') {
        $user_info = mysqli_query($conn, "SELECT id_cliente FROM usuarios WHERE username='$usuario_actual'");
        $cliente_id = ($c = mysqli_fetch_assoc($user_info)) ? $c['id_cliente'] : 0;
        $filtro = "WHERE v.id_cliente = $cliente_id";
    } else {
        $filtro = ""; // admin ve todo
    }
?>
    <h2 class="title-module">Consulta de Vehículos y Servicios</h2>
    <?php
    $sql_vehiculos = "SELECT v.placa, v.marca, v.modelo, v.color, v.anio, v.id_cliente, " .
        "(SELECT GROUP_CONCAT(CONCAT('Rep: ', tipo_mantenimiento, ' (', fecha_ingreso, ') ') SEPARATOR '<br>') " .
        "FROM reparaciones WHERE placa = v.placa) AS reparaciones, " .
        "(SELECT GROUP_CONCAT(CONCAT('Elec: ', descripcion, ' (', fecha_ingreso, ') ') SEPARATOR '<br>') " .
        "FROM electricidad WHERE placa = v.placa) AS electricidad " .
        "FROM vehiculos v $filtro ORDER BY v.placa";
    
    $res_consulta = mysqli_query($conn, $sql_vehiculos);
    if ($res_consulta && mysqli_num_rows($res_consulta) > 0) {
        while ($v = mysqli_fetch_assoc($res_consulta)) {
            echo "<div class='card' style='max-width:700px'>
                <h4>{$v['marca']} {$v['modelo']} - <strong>{$v['placa']}</strong></h4>
                <p><strong>Año:</strong> {$v['anio']} &nbsp;|&nbsp; <strong>Color:</strong> {$v['color']} &nbsp;|&nbsp; <strong>ID Cliente:</strong> {$v['id_cliente']}</p>
                <div style='background:#f1f1f1;padding:10px;border-radius:4px;'>
                    <strong>Reparaciones:</strong><br>"
                    . ($v['reparaciones'] ?? 'Sin reparaciones') .
                    "<br><br><strong>Sistemas Eléctricos:</strong><br>"
                    . ($v['electricidad'] ?? 'Sin trabajos eléctricos') .
                "</div>
              </div><br>";
        }
    } else {
        echo "<p>No hay vehículos para mostrar.</p>";
    }
    endif; 
?>

    </div>

</body>
</html>
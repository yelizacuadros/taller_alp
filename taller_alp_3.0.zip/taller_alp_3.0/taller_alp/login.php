<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST['usuario'];
    $pass = $_POST['contrasena'];

    // Consulta preparada para obtener el hash de la contraseña
    $stmt = mysqli_prepare($conn, "SELECT password, rol FROM usuarios WHERE username = ?");
    mysqli_stmt_bind_param($stmt, "s", $user);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($fila = mysqli_fetch_assoc($result)) {
       if ($user == "root" && $pass == "12345") {
            $_SESSION['usuario'] = $user;
            $_SESSION['rol'] = $fila['rol'];    
            header("Location: registro_vehiculo.php");
            exit();
        }
    }
    // Si algo falla, mensaje de error
    echo "<script>alert('Usuario o contraseña incorrectos');</script>";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceso al sistema - Taller ALP</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
    body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: radial-gradient(circle at center, #1e3a5f 0%, #0d1b2a 100%);
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
}

.login-box {
    width: 320px;
    padding: 40px 30px;
    background: #ffffff; 
    border: 1px solid #cccccc; 
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2); 
    border-radius: 20px;
    box-sizing: border-box;
    text-align: center;
}

h2 {
    color: #000000; 
    font-weight: bold;
    margin-bottom: 25px;
    font-size: 22px;
}

.avatar {
    width: 70px;
    height: 70px;
    margin: 0 auto 30px auto;
    border: 2px solid #555555; 
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 30px;
    color: #555555;
}

.input-group {
    position: relative;
    margin-bottom: 20px;
    width: 100%;
}

.input-group i {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: #888888; 
    font-size: 14px;
}

.input-group input {
    width: 100%;
    padding: 12px 10px 12px 40px;
    background: #f8f9fa; 
    border: 1px solid #dddddd;
    border-radius: 4px;
    color: #333333;
    font-size: 14px;
    box-sizing: border-box;
    outline: none;
    transition: 0.3s;
}

.input-group input:focus {
    border-color: #999999;
}

.input-group input::placeholder {
    color: #aaaaaa;
}

.btn-login {
    width: 100%;
    padding: 12px;
    background: linear-gradient(to bottom, #5ab0ee 0%, #2980b9 100%);
    border: 1px solid #1a649a;
    border-radius: 6px;
    color: #ffffff; 
    font-size: 14px;
    font-weight: bold;
    letter-spacing: 1px;
    cursor: pointer;
    text-transform: uppercase;
    transition: 0.3s;
    margin-top: 10px;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.4), 0 2px 4px rgba(0,0,0,0.2);
}

.btn-login:hover {
    background: linear-gradient(to bottom, #4a9fdd 0%, #1e70a6 100%);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.4), 0 4px 8px rgba(0,0,0,0.3);
}
    </style>
</head>
<body>
    <div class="login-box">
        <div class="avatar"><i class="fa-solid fa-user"></i></div>
        <form method="POST">
            <h2>Acceso al sistema</h2>
            <div class="input-group">
                <i class="fa-solid fa-id-badge"></i>
                <input type="text" name="usuario" class="input-form" placeholder="ID" required>
            <<div>
     <input type="password" name="contrasena" id="contrasena">
     <!-- BOTÓN CORREGIDO -->
     <button type="button" id="verPass">👁️ Ver</button>
 </div>
 <!-- SCRIPT FUERA DEL DIV, AL FINAL O ANTES DE </body> -->
 <script>
 // Espera a que cargue todo
 document.addEventListener("DOMContentLoaded", function() {
     const campo = document.getElementById("contrasena");
     const boton = document.getElementById("verPass");
     boton.addEventListener("click", function() {
         if (campo.type === "password") {
             campo.type = "text";
             boton.textContent = "🙈 Ocultar";
         } else {
             campo.type = "password";
             boton.textContent = "👁️ Ver";
         }
     });
 });
 </script>

</script>
            </div>
            <button type="submit" class="btn-login">ENTRAR</button>
        </form>
    </div>
</body>
</html>